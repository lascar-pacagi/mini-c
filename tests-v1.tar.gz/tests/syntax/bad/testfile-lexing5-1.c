    void m() { int i = 0; i +/**/= 10; }
