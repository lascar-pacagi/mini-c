void m() { if (true) ; else }
