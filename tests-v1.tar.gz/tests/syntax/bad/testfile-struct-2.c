
struct S { struct S a; };

