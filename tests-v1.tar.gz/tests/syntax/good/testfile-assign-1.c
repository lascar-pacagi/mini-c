int m() { int x; int y; y = x = 0; }
