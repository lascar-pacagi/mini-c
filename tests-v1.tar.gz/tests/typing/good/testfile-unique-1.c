int main() {
  int x;
  if (1) { int x; }
}
