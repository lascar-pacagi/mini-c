int f(int x) {}
int main() { f(); }

