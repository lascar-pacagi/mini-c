
int f(int x) { }
int main() { x; }

