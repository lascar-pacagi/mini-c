
int main() {
  int x;
  x = 65;
  putchar(x);
  putchar(10);
  return 0;
}
