
int main() {
  int c;
  c = 'A';
  putchar(c);
  c = c+1;
  putchar(c);
  putchar(10);
  return 0;
}
