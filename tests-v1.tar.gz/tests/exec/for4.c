
int main() {
  int x;
  x = 10; while (x) putchar('A' + (x = x-1));
  putchar(10);
  return 0;
}
