
int main() {
  int x;
  putchar(x = 65);
  putchar(10);
  return 0;
}
