
int main() {
  int x, y;
  x = (y = 1);
  putchar('A' + x);
  putchar(10);
  return 0;
}
