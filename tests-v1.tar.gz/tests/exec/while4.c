
int main() {
  int x;
  x = 10;
  while(x) { x = x-1; putchar('A' + x); }
  putchar(10);
  return 0;
}
