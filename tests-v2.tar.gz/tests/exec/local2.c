
int main() {
  int x, y;
  x = 65;
  putchar(x);
  x = x+1;
  putchar(x);
  y = x+1;
  putchar(x);
  putchar(y);
  putchar(10);
  return 0;
}
