
int main() {
  putchar(0101);
  putchar(10);
  return 0;
}
