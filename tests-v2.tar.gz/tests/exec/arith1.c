
int main() {
  putchar(100+4);
  putchar(102-1);
  putchar(100+2*4);
  putchar(216/2);
  putchar(3*37);
  putchar(0x20);
  putchar(118 + -(1-2));
  putchar(100 + 122 / 11);
  putchar(113 + (1<2));
  putchar(108 + (2<1));
  putchar(99 + (2==1+1));
  putchar(10 + (1==2));
  return 0;
}
