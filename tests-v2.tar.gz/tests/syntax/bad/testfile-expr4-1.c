void f() { 0 <== 0; }
