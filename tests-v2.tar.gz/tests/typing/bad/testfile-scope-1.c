int main() { { int x; } x; }
