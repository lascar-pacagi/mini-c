
int main() { int x; x->a; }
