
int main() { int p; struct S *q; putchar(p-q); }

