struct S { int a; };
struct S { int a; };
