int main() {
  putchar(1 / 0);
}
